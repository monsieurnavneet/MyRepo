package org.codejudge.sb.bo;

import org.codejudge.sb.enums.StatusEnum;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "status", "reason" })
public class ErrorResponse {

	@JsonProperty("status")
	private StatusEnum status;

	@JsonProperty("reason")
	private String reason;

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public ErrorResponse(StatusEnum status, String reason) {
		super();
		this.status = status;
		this.reason = reason;
	}

}
