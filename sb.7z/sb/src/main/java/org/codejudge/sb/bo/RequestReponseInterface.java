package org.codejudge.sb.bo;

import org.codejudge.sb.enums.LocationTypeEnum;
import org.codejudge.sb.enums.StatusEnum;

public interface RequestReponseInterface {

	public long getLeadId();

	public void setLeadId(long leadId);

	public String getFirstName();

	public void setFirstName(String firstName);

	public String getLastName();

	public void setLastName(String lastName);

	public long getMobile();

	public void setMobile(long mobile);

	public String getEmail();

	public void setEmail(String email);

	public LocationTypeEnum getLocationType();

	public void setLocationType(LocationTypeEnum locationType);

	public String getLocationString();

	public void setLocationString(String locationString);

	public StatusEnum getStatus();

	public void setStatus(StatusEnum status);

	@Override
	public String toString();
}
