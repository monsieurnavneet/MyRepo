package org.codejudge.sb.enums;

public enum LocationTypeEnum {

	Country, City, Zip;
}
