package org.codejudge.sb.service;

import java.util.List;

import org.codejudge.sb.bo.GenerateLeadRequest;
import org.codejudge.sb.bo.GenerateLeadResponse;
import org.codejudge.sb.enums.StatusEnum;
import org.codejudge.sb.repository.LeadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Service
public class LeadService {

	@Autowired
	private LeadRepository repository;

	public GenerateLeadResponse generateLead(GenerateLeadRequest request) {
		GenerateLeadResponse response = new GenerateLeadResponse();
		request.setStatus(StatusEnum.Created);
		GenerateLeadRequest result = repository.save(request);
		System.out.println("request :" + request);
		if (result != null) {
			response.setFirstName(result.getFirstName());
			response.setLastName(result.getLastName());
			response.setMobile(result.getMobile());
			response.setEmail(result.getEmail());
			response.setLocationType(result.getLocationType());
			response.setLocationString(result.getLocationString());
			response.setStatus(StatusEnum.Created);
		}
		return response;

	}

	public GenerateLeadRequest fetchLead(long leadID) {
		GenerateLeadRequest result = repository.findById(leadID).get();
		return result;
	}

	public StatusEnum updateLead(long leadId, GenerateLeadRequest UpdateRequest) {
		GenerateLeadRequest result = fetchLead(leadId);
		StatusEnum status = null;
		if (result != null) {
			result.setFirstName(UpdateRequest.getFirstName());
			result.setLastName(UpdateRequest.getLastName());
			result.setMobile(UpdateRequest.getMobile());
			result.setEmail(UpdateRequest.getEmail());
			result.setLocationType(UpdateRequest.getLocationType());
			result.setLocationString(UpdateRequest.getLocationString());
			// Updating the db data
			repository.save(result);
			status = StatusEnum.success;
		} else {
			status = StatusEnum.failure;
		}
		return status;
	}

	public void deleteLead(long leadId) {
		repository.deleteById(leadId);
	}

	// Helper Methods
	public List<GenerateLeadRequest> findByMobile(long mobile) {
		return repository.findByMobile(mobile);
	}

	// Helper Methods
	public List<GenerateLeadRequest> findByEmail(String email) {
		return repository.findByEmail(email);
	}

	// Helper Methods
	public List<GenerateLeadRequest> findByMobileAndEmail(long mobile,
			String email) {
		return repository.findByMobileAndEmail(mobile, email);
	}

}
