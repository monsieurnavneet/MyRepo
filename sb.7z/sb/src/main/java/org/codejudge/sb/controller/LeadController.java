package org.codejudge.sb.controller;

import org.codejudge.sb.bo.EmptyJsonResponse;
import org.codejudge.sb.bo.GenerateLeadRequest;
import org.codejudge.sb.bo.StatusResponse;
import org.codejudge.sb.enums.ErrorTypeEnum;
import org.codejudge.sb.enums.StatusEnum;
import org.codejudge.sb.service.LeadService;
import org.codejudge.sb.utils.ErrorResponseUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeadController {

	@Autowired
	private LeadService service;

	@Autowired
	private ErrorResponseUtils reponseUtil;

	// Generate a lead
	@PostMapping("/api/leads/")
	public ResponseEntity<Object> generateLead(
			@RequestBody GenerateLeadRequest request) {
		ResponseEntity<Object> response = null;
		try {
			if (String.valueOf(request.getMobile()).length() != 10) {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.MOBILE_LENGTH_ERROR,
						HttpStatus.BAD_REQUEST, null);
			} else if (service.findByMobileAndEmail(request.getMobile(),
					request.getEmail()).size() > 0) {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.MOBILE_EMAIL_NOT_UNIQUE,
						HttpStatus.BAD_REQUEST, null);
			} else if (service.findByMobile(request.getMobile()).size() > 0) {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.MOBILE_NOT_UNIQUE,
						HttpStatus.BAD_REQUEST, null);
			} else if (service.findByEmail(request.getEmail()).size() > 0) {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.EMAIL_NOT_UNIQUE, HttpStatus.BAD_REQUEST,
						null);
			} else {
				response = ResponseEntity.status(HttpStatus.CREATED).body(
						service.generateLead(request));
			}
		} catch (Exception e) {
			return reponseUtil.errorResponse(ErrorTypeEnum.UNKNOWN,
					HttpStatus.BAD_REQUEST, e);
		}
		return response;

	}

	// fetch a lead
	@GetMapping("/api/leads/{leadID}")
	public ResponseEntity<Object> fetchLead(@PathVariable long leadID) {
		GenerateLeadRequest result = new GenerateLeadRequest();
		ResponseEntity<Object> response = null;
		try {
			result = service.fetchLead(leadID);
			if (result == null) {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.NO_DATA_FOUND, HttpStatus.BAD_REQUEST,
						null);
			} else {
				response = ResponseEntity.status(HttpStatus.OK).body(result);
			}
		} catch (Exception e) {
			return reponseUtil.errorResponse(ErrorTypeEnum.UNKNOWN,
					HttpStatus.BAD_REQUEST, e);
		}
		return response;
	}

	// Update a lead
	@PutMapping("/api/leads/{leadId}")
	public ResponseEntity<Object> updateLead(@PathVariable long leadId,
			@RequestBody GenerateLeadRequest updateRequest) {
		ResponseEntity<Object> response = null;
		try {
			StatusEnum status = service.updateLead(leadId, updateRequest);
			if (status == StatusEnum.success) {
				response = ResponseEntity.status(HttpStatus.ACCEPTED).body(
						new StatusResponse(status));
			} else {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.NO_DATA_FOUND, HttpStatus.BAD_REQUEST,
						null);
			}
		} catch (Exception e) {
			return reponseUtil.errorResponse(ErrorTypeEnum.UNKNOWN,
					HttpStatus.BAD_REQUEST, e);
		}
		return response;
	}

	// Delete a lead
	@DeleteMapping("/api/leads/{leadId}")
	public ResponseEntity<Object> deleteLead(@PathVariable long leadId) {
		ResponseEntity<Object> response = null;
		try {
			if (service.fetchLead(leadId) == null) {
				response = reponseUtil.errorResponse(
						ErrorTypeEnum.NO_DATA_FOUND, HttpStatus.NO_CONTENT,
						null);
			}
			service.deleteLead(leadId);
		} catch (Exception e) {
			return reponseUtil.errorResponse(ErrorTypeEnum.UNKNOWN,
					HttpStatus.BAD_REQUEST, e);
		}
		response = ResponseEntity.status(HttpStatus.OK).body(
				new StatusResponse(StatusEnum.success));
		return response;
	}

	// Mapping for Null leadId
	@GetMapping("/api/leads/")
	public ResponseEntity<Object> fetchLeadForNullId() {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(
				new EmptyJsonResponse());
	}

}
