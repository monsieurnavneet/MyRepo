package org.codejudge.sb.bo;

public class MarkLeadRequest {

}
