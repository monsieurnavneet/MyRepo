package org.codejudge.sb.repository;

import java.util.List;

import org.codejudge.sb.bo.GenerateLeadRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeadRepository extends
		JpaRepository<GenerateLeadRequest, Long> {

	public List<GenerateLeadRequest> findByMobile(long mobile);

	public List<GenerateLeadRequest> findByEmail(String email);

	public List<GenerateLeadRequest> findByMobileAndEmail(long mobile,
			String email);
}
