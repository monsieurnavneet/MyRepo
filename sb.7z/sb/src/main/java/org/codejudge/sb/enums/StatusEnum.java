package org.codejudge.sb.enums;

public enum StatusEnum {
	Created, failure, Contacted, success;
}
