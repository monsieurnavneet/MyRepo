package org.codejudge.sb.bo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.codejudge.sb.enums.LocationTypeEnum;
import org.codejudge.sb.enums.StatusEnum;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@Entity
@Table(name = "lead")
@JsonPropertyOrder({ "first_name", "last_name", "mobile", "email",
		"location_type", "location_string", "status" })
@JsonIgnoreProperties({ "leadId", "lastName", "lead_id", "communication" })
public class GenerateLeadRequest {

	@Id
	@GeneratedValue
	@JsonProperty("lead_id")
	@Column(name = "lead_id")
	private long leadId;

	@JsonProperty("first_name")
	@Column(name = "first_name")
	private String firstName;

	@JsonProperty("last_name")
	@Column(name = "last_name")
	private String LastName;

	@JsonProperty("mobile")
	@Column(name = "mobile")
	@NotBlank(message = "Mobile Number is mendatory")
	private long mobile;

	@JsonProperty("email")
	@Column(name = "email")
	@NotBlank(message = "Mobile Number is mendatory")
	private String email;

	@JsonProperty("location_type")
	@Column(name = "location_type")
	@Enumerated(EnumType.STRING)
	private LocationTypeEnum locationType;

	@JsonProperty("location_string")
	@Column(name = "location_string")
	private String locationString;

	@JsonProperty("status")
	@Column(name = "status", columnDefinition = "varchar(255)")
	@Enumerated(EnumType.STRING)
	private StatusEnum status;

	@JsonProperty("communication")
	@Column(name = "communication")
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "lead_id", referencedColumnName = "lead_id")
	private CommunicationBo communication;

	public long getLeadId() {
		return leadId;
	}

	public void setLeadId(long leadId) {
		this.leadId = leadId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocationTypeEnum getLocationType() {
		return locationType;
	}

	public void setLocationType(LocationTypeEnum locationType) {
		this.locationType = locationType;
	}

	public String getLocationString() {
		return locationString;
	}

	public void setLocationString(String locationString) {
		this.locationString = locationString;
	}

	public StatusEnum getStatus() {
		return status;
	}

	public void setStatus(StatusEnum status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "GenerateLeadRequest [leadId=" + leadId + ", firstName="
				+ firstName + ", LastName=" + LastName + ", mobile=" + mobile
				+ ", email=" + email + ", locationType=" + locationType
				+ ", locationString=" + locationString + ", status=" + status
				+ "]";
	}

}
