package org.codejudge.sb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbApplicationTests {

	@Test
	void contextLoads() {
	}

}
